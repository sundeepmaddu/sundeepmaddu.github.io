# Sundeep Maddu — Product Leader Portfolio

A responsive, single-page portfolio website for GitHub Pages.

## Publish
1. Open the `sundeepmaddu.github.io` repository.
2. Choose **Add file → Upload files**.
3. Upload `index.html` from this folder and commit the changes to the `main` branch.
4. Open **Settings → Pages** and choose **Deploy from a branch**, branch `main`, folder `/ (root)`, then save if it is not already configured.
5. Visit https://sundeepmaddu.github.io after GitHub Pages finishes publishing.

## Before publishing
- Replace the LinkedIn link in `index.html` with your actual LinkedIn profile URL.
- Add a resume link if you want one.
- Review all case study wording and add only outcomes you can substantiate.
